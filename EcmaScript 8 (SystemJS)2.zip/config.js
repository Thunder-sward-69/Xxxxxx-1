SystemJS.config({
  baseURL:'https://unpkg.com/',
  defaultExtension: true,
  packages: {
    ".": {
      main: './main.js',
      defaultExtension: 'js'
    }
  },
  meta: {
    '*.js': {
      'babelOptions': {}
    }
  },
  map: {
    'plugin-babel': 'systemjs-plugin-babel@latest/plugin-babel.js',
    'systemjs-babel-build': 'systemjs-plugin-babel@latest/systemjs-babel-browser.js'
  },
  transpiler: 'plugin-babel'
});

SystemJS.import('./main')
  .catch(console.error.bind(console));


//start from here
const scroll = new LocomotiveScroll({
    el: document.querySelector('#main'),
    smooth: true
});





function movingUp(){
gsap.to(".div1",{
 // y:"-120%",
 opacity:0,
  delay:0.9,
  duration:1,
  ease:"expo.out",
  onComplete: function() {
      // Play the video
      var video = document.querySelector('.div2 video');
      video.play();
      
      var video = document.getElementById('bgvideo');
video.playbackRate = 2.5; // Double speed

      
     gsap.to(".div2",{
  y:"-120%",
  opacity:0,
  delay:2,
  opacity:1,
  duration:2,
  ease:"expo.out"
});
  }
});
}
  
    
movingUp()

var h1 = document.getElementById("part1");
h1.innerHTML ="challraha hai kya"